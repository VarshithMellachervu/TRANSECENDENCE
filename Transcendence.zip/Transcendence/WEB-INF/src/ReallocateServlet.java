import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class ReallocateServlet extends HttpServlet {

    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String dbURL = "jdbc:mysql://localhost:3306/student_transport";
        String dbUsername = "root";
        String dbPassword = "";

        Connection conn = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection(dbURL, dbUsername, dbPassword);
            conn.setAutoCommit(false);

            String query = "UPDATE buses SET occupied_seats=0 WHERE occupied_seats>=0";
            Statement stmt = conn.createStatement();
            stmt.executeUpdate(query);

            query = "SELECT stop, roll_number FROM students";
            Statement stmt1 = conn.createStatement();
            ResultSet stu = stmt1.executeQuery(query);

            while (stu.next()) {
                String stop = stu.getString("stop");
                String rn = stu.getString("roll_number");

                query = "SELECT bus_id, occupied_seats, seats FROM buses WHERE FIND_IN_SET('" + stop + "', stops) > 0";
                Statement stmt2 = conn.createStatement();
                ResultSet bus = stmt2.executeQuery(query);

                int min = Integer.MAX_VALUE;
                int bid = -1;
                while (bus.next()) {
                    int occupiedSeats = bus.getInt("occupied_seats");
                    int totalSeats = bus.getInt("seats");
                    if (occupiedSeats < min && totalSeats > occupiedSeats) {
                        min = occupiedSeats;
                        bid = bus.getInt("bus_id");
                    }
                }
                query = "UPDATE students SET bus_id=? WHERE roll_number=?";
                PreparedStatement stmt3 = conn.prepareStatement(query);
                stmt3.setInt(1, bid);
                stmt3.setString(2, rn);
                stmt3.executeUpdate();

                query = "UPDATE buses SET occupied_seats=? WHERE bus_id=?";
                PreparedStatement stmt4 = conn.prepareStatement(query);
                stmt4.setInt(1, min + 1);
                stmt4.setInt(2, bid);
                stmt4.executeUpdate();
                
            }

            conn.commit(); 
            RequestDispatcher rd = request.getRequestDispatcher("success.html");
            rd.forward(request, response);

        } catch (Exception e) {
            if (conn != null) {
                try {
                    conn.rollback(); 
                } catch (SQLException se) {
                    out.println("Rollback failed: " + se.getMessage());
                }
            }
            out.println("Error: " + e.getMessage());
        } finally {
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException se) {
                    out.println("Connection close failed: " + se.getMessage());
                }
            }
        }
    }
}

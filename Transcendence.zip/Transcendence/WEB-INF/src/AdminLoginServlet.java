import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
public class AdminLoginServlet extends HttpServlet {

    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out=response.getWriter();
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String dbURL = "jdbc:mysql://localhost:3306/student_transport";
        String dbUsername = "root";
        String dbPassword = "";

        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn = DriverManager.getConnection(dbURL, dbUsername, dbPassword);
            String query = "SELECT * FROM admin WHERE username = '"+username+"' AND password ='"+password+"'";
            Statement stmt=conn.createStatement();
            ResultSet result = stmt.executeQuery(query);
            if (result.next()) {
                RequestDispatcher rd=request.getRequestDispatcher("adminDashboard.html");
                rd.forward(request,response);
                // out.println("Correct");
            } else {
                        RequestDispatcher rd=request.getRequestDispatcher("/adminLogin.html");
                        out.print("<p style=\"color: red;\">Incorrect Username or Password</p>");
                        rd.include(request,response);
            }
            result.close();
            stmt.close();
            conn.close();
        } catch (Exception e) {
           
            out.println(e);
        }
    }
}
